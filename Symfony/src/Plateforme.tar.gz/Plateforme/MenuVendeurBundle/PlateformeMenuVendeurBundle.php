<?php

namespace Plateforme\MenuVendeurBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlateformeMenuVendeurBundle extends Bundle
{
}
