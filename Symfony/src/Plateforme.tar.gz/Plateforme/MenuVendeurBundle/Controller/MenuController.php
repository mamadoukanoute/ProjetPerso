<?php

namespace Plateforme\MenuVendeurBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class MenuController extends Controller
{
    public function accueilAction()
    {
        return $this->render('PlateformeMenuVendeurBundle:Menu:accueil.html.twig');
    }

 public function accueilProfilAction()
    {
        return $this->render('PlateformeMenuVendeurBundle:Profil:accueil.html.twig');
    }






}
