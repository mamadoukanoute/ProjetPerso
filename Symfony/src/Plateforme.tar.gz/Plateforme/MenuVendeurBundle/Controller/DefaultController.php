<?php

namespace Plateforme\MenuVendeurBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('PlateformeMenuVendeurBundle:Default:index.html.twig');
    }
}
