<?php

namespace Plateforme\ProduitBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Commandes
 *
 * @ORM\Table(name="commandes")
 * @ORM\Entity(repositoryClass="Plateforme\ProduitBundle\Repository\CommandesRepository")
 */
class Commandes
{

    /**
     * @var int
     *
     * @ORM\Column(name="cmdid", type="integer", unique=true)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $cmdid;

    /**
     * @var int
     *
     * @ORM\Column(name="pid", type="integer")
     */
    private $pid;

    /**
     * @var int
     *
     * @ORM\Column(name="fournid", type="integer")
     */
    private $fournid;

    /**
     * @var string
     *
     * @ORM\Column(name="statut", type="string", length=255)
     */
    private $statut;


    /**
     * Get cmdid
     *
     * @return int
     */
    public function getCmdid()
    {
        return $this->cmdid;
    }

    /**
     * Set pid
     *
     * @param integer $pid
     *
     * @return Commandes
     */
    public function setPid($pid)
    {
        $this->pid = $pid;

        return $this;
    }

    /**
     * Get pid
     *
     * @return int
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * Set fournid
     *
     * @param integer $fournid
     *
     * @return Commandes
     */
    public function setFournid($fournid)
    {
        $this->fournid = $fournid;

        return $this;
    }

    /**
     * Get fournid
     *
     * @return int
     */
    public function getFournid()
    {
        return $this->fournid;
    }

    /**
     * Set statut
     *
     * @param string $statut
     *
     * @return Commandes
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return string
     */
    public function getStatut()
    {
        return $this->statut;
    }
}

