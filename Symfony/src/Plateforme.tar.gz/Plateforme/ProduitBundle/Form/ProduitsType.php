<?php

namespace Plateforme\ProduitBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
class ProduitsType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

		
        $builder
            ->add('nom',TextType::class)
       ->add('description',TextareaType::class, array('attr' => array('class' => 'ckeditor'), 'required' => false))
            ->add('qte',TextType::class)
            ->add('prix',TextType::class)
 ->add('catid',ChoiceType::class, array('choices' => array(
'Produit laitier' => '1','Boucherie' => '2','Entretien Maison' => '3',
        
    ),))
        ;
    }
    


    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Plateforme\ProduitBundle\Entity\Produits'
        ));
    }
}
