<?php

namespace Plateforme\ProduitBundle\Controller;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Plateforme\ProduitBundle\Entity\Commandes;
use Plateforme\ProduitBundle\Entity\Panier;
use Plateforme\ProduitBundle\Form\CommandesType;
use Plateforme\ProduitBundle\Form\PanierTest;
use Symfony\Component\HttpFoundation\Response;

class CommandesController extends Controller
{

public function depotAction(Request $request)
    {
    

$user = $this->get('security.token_storage')->getToken()->getUser();
$userid= $user->getId();
	$repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Panier');
$listePanier = $repository2->findByUserid($userid);
foreach($listePanier as $panier){
echo $panier->getProdid();
$commande=new Commandes();
$commande->setPid($panier->getPid());
$commande->setStatut('en cours');
$commande->setFournid($this->get_fournisseur($panier->getProdid()));
$repository->persist($commande);
$repository->flush();


}




 return $this->redirectToRoute('afficheCommandes');
//return new response("problème");
}




public function afficherAction(Request $request)
    {
    $repository = $this->getDoctrine()
                   ->getManager();

if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') && $this->get('security.authorization_checker')->isGranted('ROLE_CLIENT')) {
$user = $this->get('security.token_storage')->getToken()->getUser();
$userid= $user->getId();
$query = $repository->createQuery('SELECT a FROM PlateformeProduitBundle:Panier a JOIN PlateformeProduitBundle:Commandes cmd WHERE (a.pid=cmd.pid AND a.userid=$userid)');
$liste = $query->getResult();
 return $this->render('PlateformeProduitBundle:Commandes:afficher.html.twig',array('liste' => $liste));
}
if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') && $this->get('security.authorization_checker')->isGranted('ROLE_VENDEUR')) {
$user = $this->get('security.token_storage')->getToken()->getUser();
$userid= $user->getId();
 $repository2=    $repository ->getRepository('PlateformeProduitBundle:Commandes');

$listeCommande = $repository2->findByFournid($userid);

 return $this->render('PlateformeMenuVendeurBundle:Menu:listeCommandes.html.twig',array('liste' => $listeCommande));


}
}

public function accepterAction($pid)
    {

    $repository = $this->getDoctrine()
                   ->getManager();
echo $pid;
$repository2=$repository->getRepository('PlateformeProduitBundle:Panier');
	 
		$listeCommande = $repository2->findOneByPid($pid);
		$total=$this->getqte($listeCommande->getProdid());
		$sub=$total-$listeCommande->getQte();
		if($sub<0) {
		echo"STOCK INSUFFISANT<br />
		Veuillez voir le nombre de quantité disponible en Stock";
		}
		if($sub==0||$sub>0){
			 $repository3=    $repository ->getRepository('PlateformeProduitBundle:Commandes');
			$Commande = $repository3->findOneByPid($pid);
			$Commande->setStatut("acceptée");
			$repository4=    $repository ->getRepository('PlateformeProduitBundle:Produits');
			$produit = $repository4->findOneByProdid($listeCommande->getProdid());
			$produit->setQte($sub);
		  $repository->flush();


	}
		return $this->redirectToRoute('afficheCommandes');
}
public function refuserAction($pid,Request $request){
   $repository = $this->getDoctrine()
                   ->getManager();
 $repository3=    $repository ->getRepository('PlateformeProduitBundle:Commandes');
			$Commande = $repository3->findOneByPid($pid);
	//}      
		$Commande->setStatut("refusée");
		  $repository->flush();
//return new response("dd");
		return $this->redirectToRoute('afficheCommandes');
return new response("dd");
	}















function getqte($prodid){ 
 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Produits');

$fournisseur = $repository2->findOneByProdid($prodid);

return $fournisseur->getQte();
}







function get_fournisseur($prodid){ 

 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Produits');

$fournisseur = $repository2->findOneByProdid($prodid);

return $fournisseur->getFournid();
}
}
