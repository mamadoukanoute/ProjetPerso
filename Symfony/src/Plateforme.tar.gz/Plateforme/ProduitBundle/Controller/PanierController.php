<?php

namespace Plateforme\ProduitBundle\Controller;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Plateforme\ProduitBundle\Entity\Panier;
use Plateforme\ProduitBundle\Form\PanierType;
use Plateforme\ProduitBundle\Form\PanierTest;
use Symfony\Component\HttpFoundation\Response;

class PanierController extends Controller
{

public $v=0;



public function AccueilAction()
{
return $this->render('PlateformeVieetudianteBundle:Annonces:accueil.html.twig');
}





   

/*public function afficherAction(){

$user = $this->get('security.context')->getToken()->getUser();
$userid= $user->getId();


$repository = $this->getDoctrine()
                   ->getManager();
$repository2= $repository->getRepository('PlateformeProduitBundle:Panier');
//$enc=$repository;
$panier = $repository2->find($userid);

return $this->render('PlateformeProduitBundle:Panier:afficherPanier.html.twig',array('panier' => $panier));
///return new response(" ");
 }*/
 




/*********************Afficher,Modifier,Supprimer le panier************************************************************************/

public function afficherPanierAction(Request $request)
{

$user = $this->get('security.token_storage')->getToken()->getUser();
$userid= $user->getId();
 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Panier');
  $listeProduits=    $repository ->getRepository('PlateformeProduitBundle:Produits');
$listePanier = $repository2->findByUserid($userid);
/*$panier=new Panier();
$form = $this->createForm(PanierType::class, $panier);
 $responseArray['form1']=$form->createView();
//$request = $this->get('request');
//// On vérifie qu'elle est de type POST
if ($request->getMethod() == 'POST') {
$form->handleRequest($request);
 if($form->isValid()) {
 $em = $this->getDoctrine()->getManager();
$em->persist($produits);
$em->flush();
}
}*/

//$listePanier = $repository2->findByUserid($userid);
 return $this->render('PlateformeProduitBundle:Panier:afficher.html.twig',array('listePanier'=>$listePanier,'listeProduits'=>$listeProduits));

}

//else return $this->render('PlateformeProduitBundle:Panier:afficher.html.twig',array('listePanier'=>$listePanier,'listeProduits'=>$listeProduits,'arrayListe' =>$responseArray ));
  


/******************************************Modifier le panier****************************************************/

public function updatePanierAction($pid,Request $request)
{

 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Panier');
$listepanier = $repository2->findOneByPid($pid);
$panier=$listepanier;
$session=new Session();
$quantiteold=$panier->getQte();
$quantitenew;
$resultatqte;
$quantitesession=intval($session->get('panier'));
//echo $quantitesession;
$qtefinale;
//$panier=$listepanier;
$form = $this->createForm( PanierType::class, $panier);
if ($request->getMethod() == 'POST'){
$form->handleRequest($request);
 if($form->isValid()) {
$quantitenew=$panier->getQte();
$resultatqte=$quantitenew-$quantiteold;
$qtefinale=$quantitesession+$resultatqte;
		$session->set('panier',$qtefinale);
// On l'enregistre notre objet $article dans la base de
/*$em = $this->getDoctrine()->getManager();*/
//s$repository->refresh($panier);
$repository ->flush();
 return $this->redirectToRoute('afficherPanier');
}
}
return $this->render('PlateformeProduitBundle:Panier:depot.html.twig',array('form' => $form->createView(),));

}

    



/******************************************************Supprimer le panier *****************************************************************/


public function deletePanierAction($pid)
{

 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Panier');

$panier = $repository2->find($pid);

$repository->remove($panier);
// On redirige vers la page de visualisation de l'article
return new response ("La suppression a réussi");
}    
}
