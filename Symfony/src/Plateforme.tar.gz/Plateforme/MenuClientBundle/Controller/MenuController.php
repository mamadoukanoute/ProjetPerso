<?php

namespace Plateforme\MenuClientBundle\Controller;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Plateforme\ProduitBundle\Entity\Panier;
class MenuController extends Controller
{

/*public function nbrepanier($userid){

return $i;



}*/


    public function accueilAction()
    {
$user = $this->get('security.token_storage')->getToken()->getUser();
$userid= $user->getId();
			$i=0;
 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Panier');
$listepanier = $repository2->findByUserid($userid);

foreach($listepanier as $panier){
$i=$i+$panier->getQte();

};
		$session=new Session();
		$session->set('panier',$i);


        return $this->render('PlateformeMenuClientBundle:Menu:accueil.html.twig',array('panier'=>$i,'user'=>$user));
    }


    public function rechercheaccueilAction()
    {

        return $this->render('PlateformeMenuClientBundle:Menu:recherche.html.twig');
    }

 public function recherchecategorieformAction()
    {

		$repository = $this->getDoctrine()
                  			 ->getManager();
    		$repository2=    $repository ->getRepository('PlateformeProduitBundle:Categories');
		$categories = $repository2->findAll();

        return $this->render('PlateformeMenuClientBundle:Menu:rechercheCatid.html.twig',array('categories'=>$categories ));
    }

 public function recherchecategorieAction()
    {



$catid=$_POST['catid'];

		 $repository = $this->getDoctrine()
                   ->getManager();
    $repository2=    $repository ->getRepository('PlateformeProduitBundle:Produits');

$listeproduits = $repository2->findByCatid($catid);
 return $this->render('PlateformeMenuClientBundle:Menu:afficher.html.twig',array('listeproduits'=>$listeproduits,));

    }




 public function recherchenomformAction()
    {

		$repository = $this->getDoctrine()
                  			 ->getManager();
    		$repository2=    $repository ->getRepository('PlateformeProduitBundle:Categories');
		$categories = $repository2->findAll();

        return $this->render('PlateformeMenuClientBundle:Menu:rechercheNom.html.twig',array('categories'=>$categories ));
    }

 public function recherchenomAction()
    {



$nom=$_POST['nom'];

		 $repository = $this->getDoctrine()
                   ->getManager();
$query = $repository->createQuery("SELECT a FROM PlateformeProduitBundle:Produits a WHERE a.nom LIKE '%$nom%'   ");
$listeproduits = $query->getResult();

 return $this->render('PlateformeMenuClientBundle:Menu:afficher.html.twig',array('listeproduits'=>$listeproduits,));

    }






  public function accueilProfilAction()
    {
        return $this->render('PlateformeMenuClientBundle:Profil:accueil.html.twig');
    }






}
