<?php

namespace Plateforme\MenuSellerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlateformeMenuSellerBundle extends Bundle
{
}
