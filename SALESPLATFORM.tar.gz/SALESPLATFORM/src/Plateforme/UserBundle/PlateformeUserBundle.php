<?php

namespace Plateforme\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlateformeUserBundle extends Bundle
{
}
