<?php

namespace Plateforme\ProduitBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlateformeProduitBundle extends Bundle
{
}
