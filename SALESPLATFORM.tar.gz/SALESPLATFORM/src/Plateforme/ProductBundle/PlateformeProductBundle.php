<?php

namespace Plateforme\ProductBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlateformeProductBundle extends Bundle
{
}
