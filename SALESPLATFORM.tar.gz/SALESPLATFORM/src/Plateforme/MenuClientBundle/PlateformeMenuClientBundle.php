<?php

namespace Plateforme\MenuClientBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PlateformeMenuClientBundle extends Bundle
{
}
